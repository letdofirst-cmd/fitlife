// Backend + data tests. No dependencies: run with `node tests/backend.test.js`.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.join(__dirname, '..');
const store = {};
global.window = global;
global.localStorage = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: (k) => { delete store[k]; } };
global.addEventListener = () => {};
for (const f of ['data.js', 'backend.js']) vm.runInThisContext(fs.readFileSync(path.join(root, f), 'utf8'), { filename: f });
const B = FitLife.backend, D = FitLife.data, U = FitLife.util;
const ADMIN = 'hallosaini3@gmail.com';
const ADMIN_PW = process.env.FITLIFE_ADMIN_PW; // admin tests run only when this is set, so the password is never stored in the repo

const skip = async (name) => console.log('  skip ' + name + '  (set FITLIFE_ADMIN_PW to run)');
let n = 0;
const test = async (name, fn) => { try { await fn(); n++; console.log('  ok  ' +
  name); } catch (e) { console.error('FAIL ' + name + '\n', e); process.exit(1); } };

(async () => {
  await test('util: local day helpers and short names', () => {
    assert.equal(U.shortName('vishnu kumar singhania'), 'Vishnu S.');
    assert.equal(U.shortName('Meera'), 'Meera');
    assert.equal(U.displayName('shashank soam'), 'Shashank Soam');
    assert.equal(U.displayName('McDonald'), 'McDonald');
    assert.match(U.dayKey(new Date(2026, 0, 5)), /^2026-01-05$/);
    assert.equal(U.dayNumber(), Math.floor(U.parseKey(U.dayKey()).getTime() / 86400000));
    assert.equal(U.esc('<a href="x">&\'</a>'), '&lt;a href=&quot;x&quot;&gt;&amp;&#39;&lt;/a&gt;');
  });

  await test('content: every plan/routine/badge references real exercises and metrics', () => {
    const ids = new Set(D.EXERCISES.map((e) => e.id));
    assert.equal(ids.size, D.EXERCISES.length, 'duplicate exercise ids');
    D.PLANS.forEach((p) => { assert.equal(p.days.length, 7); p.days.forEach((d) => d.ex.forEach((id) => assert.ok(ids.has(id), p.id +
      ' -> ' + id))); });
    D.ROUTINES.forEach((r) => { assert.ok(D.CATEGORIES.some((c) => c.id === r.cat)); r.ex.forEach((id) => assert.ok(ids.has(id), r.id +
      ' -> ' + id)); });
    D.EXERCISES.forEach((e) => { assert.ok(e.steps.length >= 3 && e.min > 0 && e.pts > 0, e.id); assert.ok(D.CATEGORIES.some((c) => c.id === e.cat)); });
    const metrics = ['sessions', 'deskSessions', 'yogaSessions', 'longestStreak', 'points', 'mealPlans', 'hydrationDays'];
    D.BADGES.forEach((b) => assert.ok(metrics.includes(b.metric), b.id));
  });

  await (ADMIN_PW ? test : skip)('admin: seeded account logs in only with the Admin login type', async () => {
    const a = await B.login(ADMIN, ADMIN_PW, 'admin');
    assert.equal(a.role, 'admin');
    assert.equal(a.hash, undefined);
    await assert.rejects(() => B.login(ADMIN, ADMIN_PW, 'user'), /Choose the Admin login type/);
    await assert.rejects(() => B.login(ADMIN, ADMIN_PW), /Choose the Admin login type/);
    assert.equal((await B.login(' HalloSaini3@Gmail.com ', ADMIN_PW, 'admin')).role, 'admin');
    B.logout();
    await assert.rejects(() => B.signup({ name: 'Evil', email: ADMIN, password: '123456' }), /already exists/);
  });

  await test('members: signup validation, role, and cannot use admin functions', async () => {
    await assert.rejects(() => B.signup({ name: 'a', email: 'x@y.co', password: '123456' }), /name/);
    await assert.rejects(() => B.signup({ name: 'Asha Rao', email: 'bad', password: '123456' }), /valid email/);
    await assert.rejects(() => B.signup({ name: 'Asha Rao', email: 'a@b.co', password: '123' }), /6 characters/);
    const m = await B.signup({ name: 'meera k', email: 'M@x.com', password: 'secret1', occupation: 'home' });
    assert.equal(m.role, 'member');
    assert.equal(m.weeklyGoal, 150);
    await assert.rejects(() => B.signup({ name: 'Other', email: 'm@x.com', password: 'secret1' }), /already exists/);
    assert.throws(() => B.adminSummary(), /Only the admin/);
    assert.throws(() => B.adminAddExercise({}), /Only the admin/);
    await assert.rejects(() => B.adminSetVideoLink('squats', 'https://youtu.be/dQw4w9WgXcQ'), /Only the admin/);
    B.logout();
    await assert.rejects(() => B.login('m@x.com', 'secret1', 'admin'), /not an admin/);
    await B.login('m@x.com', 'secret1', 'user');
    // tampering with the stored role does not grant admin
    const db = JSON.parse(store['fitlife:v1']); db.users.forEach((u) => { u.role = 'admin'; }); store['fitlife:v1'] = JSON.stringify(db);
    assert.equal(B.currentUser().role, 'member');
  });

  await test('login throttle: 5 wrong tries pause that email', async () => {
    for (let i = 0; i < 5; i++) await assert.rejects(() => B.login('m@x.com', 'nope' + i, 'user'), /incorrect/);
    await assert.rejects(() => B.login('m@x.com', 'secret1', 'user'), /Too many attempts/);
  });

  const me = () => B.currentUser().id;
  await test('sessions: clamped to what the exercise is worth, streaks, undo', async () => {
    // reset the throttle by using a fresh account
    const u = await B.signup({ name: 'Ravi T', email: 'ravi@x.com', password: 'secret1' });
    assert.throws(() => B.recordSession(u.id, 'nope', { minutes: 2, points: 10 }));
    assert.throws(() => B.recordSession(u.id, 'neck-rolls', { minutes: 0, points: 10 }));
    const r = B.recordSession(u.id, 'neck-rolls', { minutes: 999, points: 99999 }); // neck-rolls: 2 min, 10 pts
    assert.equal(r.stats.minutes, 2); assert.equal(r.stats.points, 10);
    assert.equal(r.newBadges.map((b) => b.id).join(), 'first-step');
    const d = B.getData(u.id);
    for (let i = 1; i <= 6; i++) d.sessions.push({ id: 'x' + i, exId: 'neck-rolls', name: 'n', cat: 'desk', min: 2, pts: 10, day: U.dayKey(U.addDays(new Date(), -i)), at: 0 });
    let s = B.stats(u.id);
    assert.equal(s.streak, 7); assert.equal(s.longestStreak, 7);
    d.sessions = d.sessions.filter((x) => x.day !== U.dayKey());
    assert.equal(B.stats(u.id).streak, 6, 'streak survives until tonight');
    d.sessions = d.sessions.filter((x) => x.day !== U.dayKey(U.addDays(new Date(), -1)));
    assert.equal(B.stats(u.id).streak, 0, 'a missed day breaks it');
    const first = B.recordSession(u.id, 'child-pose', { minutes: 4, points: 15 });
    B.deleteSession(u.id, B.recentSessions(u.id, 1)[0].id);
    assert.equal(B.stats(u.id).sessions, 5);
    assert.throws(() => B.deleteSession(u.id, 'gone'), /already removed/);
    assert.ok(first.stats.sessions > 0);
  });

  await test('profile: integer age, weekly goal, ranges', async () => {
    const id = me();
    B.updateProfile(id, { age: '25.7', sex: 'male', heightCm: '175', weightKg: '70', activity: 'light', weeklyGoal: '200' });
    const u = B.currentUser();
    assert.equal(u.age, 26); assert.equal(u.weeklyGoal, 200);
    assert.throws(() => B.updateProfile(id, { age: '5' }), /Age must be/);
    assert.throws(() => B.updateProfile(id, { weeklyGoal: '5' }), /Weekly goal/);
    assert.throws(() => B.updateProfile(id, { weightKg: 'abc' }), /Weight/);
    assert.equal(B.updateProfile(id, { weeklyGoal: '' }).weeklyGoal, 150, 'blank goal falls back to the default');
  });

  await test('nutrition: deterministic plans respect diet; estimates sane; under-18 gets maintenance only', () => {
    assert.deepEqual(B.generateDayPlan('vegan', 3), B.generateDayPlan('vegan', 3));
    for (let seed = 1; seed < 200; seed++) for (const [diet, max] of [['vegan', 0], ['veg', 1], ['egg', 2], ['any', 3]]) {
      B.generateDayPlan(diet, seed).items.forEach((i) => assert.ok(D.MEALS[i.slot].find((x) => x.n === i.name).t <= max));
    }
    const u = B.currentUser();
    const maintain = B.nutritionTargets(u, 'maintain');
    assert.ok(maintain.kcal >= 2250 && maintain.kcal < 2500);
    assert.ok(B.nutritionTargets(u, 'lose').kcal < maintain.kcal);
    const teen = Object.assign({}, u, { age: 16 });
    assert.equal(B.nutritionTargets(teen, 'lose').kcal, B.nutritionTargets(teen, 'maintain').kcal);
    assert.equal(B.nutritionTargets(Object.assign({}, u, { age: null }), 'maintain'), null);
    assert.ok(B.saveMealPlan(me(), { diet: 'any', kcal: 1800, items: B.generateDayPlan('any', 1).items }).some((b) => b.id === 'nutrition'));
  });

  await test('water: add, remove, cap, target from weight', () => {
    const id = me();
    assert.equal(B.addWater(id, 1).glasses, 1);
    assert.equal(B.addWater(id, -5).glasses, 0);
    assert.equal(B.getWater(id), 0);
    assert.equal(B.addWater(id, 999).glasses, 30);
    assert.equal(B.waterTarget({ weightKg: 70 }), 10);
    assert.equal(B.waterTarget({}), 8);
  });

  await test('export -> import round trip, and hostile files are cleaned or rejected', () => {
    const id = me();
    const before = B.stats(id);
    const file = B.exportData(id);
    assert.equal(JSON.parse(file).profile.hash, undefined, 'export never contains the password hash');
    B.resetProgress(id);
    assert.equal(B.stats(id).sessions, 0);
    const res = B.importData(id, file);
    assert.equal(res.sessions, before.sessions);
    assert.equal(B.stats(id).points, before.points);
    assert.throws(() => B.importData(id, 'not json'), /not a FitLife backup/);
    assert.throws(() => B.importData(id, '{"data":{}}'), /not a FitLife backup/);
    const evil = JSON.stringify({ data: {
      sessions: [
        { day: '2026-01-01', min: 5, pts: 50, cat: 'desk', name: '<img src=x onerror=alert(1)>', exId: 'x' },
        { day: 'yesterday', min: 5, pts: 5 }, { day: '2026-01-02', min: -3, pts: 5 }, { day: '2026-01-03', min: 5, pts: 999999 }, null,
      ],
      meals: [{ day: '2026-01-01', diet: 'weird', kcal: 'lots', items: [{ name: 'x'.repeat(500) }] }],
      water: { '2026-01-01': 4, '2026-01-02': 9999, nope: 3 }, planId: 'evil-plan', reminder: { on: 1, every: 7 },
    } });
    const r2 = B.importData(id, evil);
    assert.equal(r2.sessions, 1);
    const d = B.getData(id);
    assert.equal(d.planId, null); assert.equal(d.reminder.every, 60); assert.deepEqual(Object.keys(d.water), ['2026-01-01']);
    assert.ok(d.meals[0].items[0].name.length <= 100 && d.meals[0].diet === 'any');
    B.resetProgress(id);
  });

  await test('leaderboard: real accounts only, short names, ranked, admin hidden', async () => {
    let lb = B.leaderboard('all');
    assert.ok(lb.length >= 1 && lb.every((r, i) => r.rank === i + 1));
    assert.ok(lb.find((r) => r.me), 'the current user is on the board');
    assert.ok(!lb.some((r) => /Admin/.test(r.name)), 'admin is not a player');
    for (let i = 0; i < 3; i++) await B.signup({ name: 'Extra Person' + i, email: 'e' + i + '@x.com', password: 'secret1' });
    await B.login('ravi@x.com', 'secret1', 'user');
    B.recordSession(me(), 'squats', { minutes: 5, points: 20 });
    lb = B.leaderboard('week');
    assert.equal(lb.length, 5, 'exactly the real accounts (ravi + meera + 3 extras), nothing invented');
    assert.equal(lb[0].name, 'Ravi T.');
    assert.equal(lb[0].rank, 1);
    assert.ok(lb.every((r) => !('sample' in r)));
  });

  await (ADMIN_PW ? test : skip)('videos: link parsing and validation', async () => {
    B.logout(); await B.login(ADMIN, ADMIN_PW, 'admin');
    const ok = {
      'https://www.youtube.com/watch?v=dQw4w9WgXcQ': 'youtube', 'https://youtu.be/dQw4w9WgXcQ?t=5': 'youtube', 'https://www.youtube.com/shorts/dQw4w9WgXcQ': 'youtube',
      'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ': 'youtube', 'https://vimeo.com/76979871': 'vimeo', 'https://cdn.example.com/a/squat.mp4': 'direct', 'http://x.com/a/b.webm?x=1': 'direct',
    };
    for (const [url, kind] of Object.entries(ok)) {
      const v = await B.adminSetVideoLink('squats', url, 'Form guide');
      assert.equal(v.kind, kind, url);
      assert.ok(kind === 'direct' || /^https:\/\/(www\.youtube-nocookie\.com\/embed|player\.vimeo\.com\/video)\//.test(v.embed), url);
    }
    for (const bad of ['javascript:alert(1)', 'not a url', 'ftp://x.com/a.mp4', 'https://example.com/page', 'data:text/html,hi']) await assert.rejects(() => B.adminSetVideoLink('squats', bad), undefined, bad);
    await assert.rejects(() => B.adminSetVideoLink('nope', 'https://youtu.be/dQw4w9WgXcQ'), /Pick an exercise/);
    assert.equal(B.videoFor('squats').title, 'Form guide');
    assert.equal(B.videoFor('plank'), null);
    B.adminRemoveVideo('squats'); assert.equal(B.videoFor('squats'), null);
    await assert.rejects(() => B.adminSetVideoFile('squats', { size: 10, type: 'image/png', name: 'a.png' }), /not a video/);
    await assert.rejects(() => B.adminSetVideoFile('squats', { size: 300 * 1024 * 1024, type: 'video/mp4', name: 'a.mp4' }), /over 200 MB/);
    await assert.rejects(() => B.adminSetVideoFile('squats', null), /Choose a video/);
  });

  await (ADMIN_PW ? test : skip)('admin: exercises, removals, protections, reset', async () => {
    const ex = B.adminAddExercise({ name: 'Test move', cat: 'desk', level: 'beginner', min: 3, pts: 12, steps: 'one\ntwo' });
    assert.ok(B.findExercise(ex.id));
    assert.throws(() => B.adminAddExercise({ name: 'x', cat: 'desk', level: 'beginner', min: 3, pts: 12, steps: 'a' }), /Name/);
    await B.adminSetVideoLink(ex.id, 'https://youtu.be/dQw4w9WgXcQ');
    B.adminRemoveExercise(ex.id);
    assert.equal(B.findExercise(ex.id), null); assert.equal(B.videoFor(ex.id), null);
    assert.throws(() => B.deleteAccount('u-admin'), /cannot be deleted/);
    assert.throws(() => B.adminRemoveUser('u-admin'), /own account/);
    const sum = B.adminSummary();
    assert.ok(sum.users.some((u) => u.role === 'admin') && sum.totals.users >= 5);
    B.adminResetAll();
    assert.equal(B.currentUser(), null);
    assert.equal((await B.login(ADMIN, ADMIN_PW, 'admin')).role, 'admin', 'admin is reseeded after a reset');
    assert.equal(B.adminSummary().totals.users, 1);
  });

  await test('storage: corrupted data does not crash the app', () => {
    store['fitlife:v1'] = '{not json';
    assert.doesNotThrow(() => B.currentUser());
  });

  console.log('\n' + n + ' backend tests passed');
})();
