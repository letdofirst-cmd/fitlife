const { chromium } = require('playwright');
const path = require('path');
const BASE = process.env.BASE_URL || 'http://localhost:4173/index.html';
const ADMIN_EMAIL = 'hallosaini3@gmail.com';
const ADMIN_PW = process.env.FITLIFE_ADMIN_PW; // the admin password is never stored in the repo
if (!ADMIN_PW) { console.log('Skipped: set FITLIFE_ADMIN_PW to run the admin UI tests.'); process.exit(0); }
const VIDEO = path.join(__dirname, 'fixtures', 'test.webm');
const assert = require('assert');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1360, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/fonts\.g|ERR_NAME|ERR_INTERNET|Failed to load resource|youtube|net::/.test(m.text())) errors.push('console: ' + m.text()); });
  const go = async (r) => { await page.click(`.side-nav [data-route=${r}]`); await page.waitForFunction(x => location.hash === '#/' + x, r); await page.waitForTimeout(80); };
  const login = async (email, pw, type) => {
    await page.locator('.login-type label', { hasText: type === 'admin' ? 'Admin' : 'User' }).click();
    await page.fill('#login-form [name=email]', email); await page.fill('#login-form [name=password]', pw);
    await page.click('#login-form button[type=submit]');
  };

  await page.goto(BASE);
  await page.waitForSelector('#auth-view:not(.hidden)');

  // wrong admin password, case-sensitive
  await login(ADMIN_EMAIL, '@teambreak', 'admin');
  await page.waitForFunction(() => document.querySelector('#login-error').textContent.length > 0);
  assert.match(await page.textContent('#login-error'), /incorrect/);
  // right admin password but the User login type is refused
  await login(ADMIN_EMAIL, ADMIN_PW, 'user');
  await page.waitForFunction(() => /Choose the Admin login type/.test(document.querySelector('#login-error').textContent));
  assert.ok(await page.isHidden('#app-view'));

  // admin logs in through the same form
  await login('  HalloSaini3@Gmail.com', ADMIN_PW, 'admin');
  await page.waitForSelector('#app-view:not(.hidden)');
  await page.waitForFunction(() => location.hash === '#/admin');
  assert.equal(await page.textContent('#top-department'), 'Administrator');
  assert.equal(await page.textContent('#page-title'), 'Admin overview');
  assert.ok(await page.isVisible('#admin-nav'));
  assert.ok(await page.isHidden('#user-nav'), 'user nav hidden for admin');
  assert.ok(await page.isHidden('#reminder-btn'));
  assert.ok(!/Admin studio/.test(await page.innerText('#app-view')), 'no Admin studio anywhere');
  // admin cannot wander into the member pages
  await page.evaluate(() => { location.hash = '#/exercises'; });
  await page.waitForTimeout(200);
  assert.equal(await page.textContent('#page-title'), 'Admin overview');
  await go('admin-videos');
  await page.waitForTimeout(200);

  // video table lists every exercise
  const rows = await page.locator('.table-wrap.tall tbody tr').count();
  assert.ok(rows >= 31, 'video table rows ' + rows);

  // (1) link video on Bodyweight squats
  const squatRow = page.locator('.table-wrap.tall tr', { hasText: 'Bodyweight squats' });
  await squatRow.locator('[data-action=video-edit]').click();
  await page.waitForSelector('#video-form');
  await page.click('#video-form button[type=submit]');
  assert.match(await page.textContent('#video-error'), /Choose a video file or paste a link/);
  await page.fill('#video-form [name=url]', 'javascript:alert(1)');
  await page.click('#video-form button[type=submit]');
  assert.match(await page.textContent('#video-error'), /full video link/);
  await page.fill('#video-form [name=url]', 'https://example.com/some-page');
  await page.click('#video-form button[type=submit]');
  assert.match(await page.textContent('#video-error'), /YouTube or Vimeo/);
  await page.setInputFiles('#video-form [name=file]', VIDEO);
  await page.fill('#video-form [name=url]', 'https://youtu.be/dQw4w9WgXcQ');
  await page.click('#video-form button[type=submit]');
  assert.match(await page.textContent('#video-error'), /not both/);
  await page.setInputFiles('#video-form [name=file]', []);
  await page.fill('#video-form [name=title]', 'Squat form guide');
  await page.click('#video-form button[type=submit]');
  await page.waitForSelector('.toast-ok:has-text("Video saved")');
  assert.equal(await page.locator('.modal').count(), 0);
  assert.match(await squatRow.innerText(), /Link: youtube/);

  // (2) file upload on Plank holds
  const plankRow = page.locator('.table-wrap.tall tr', { hasText: 'Plank holds' });
  await plankRow.locator('[data-action=video-edit]').click();
  await page.setInputFiles('#video-form [name=file]', VIDEO);
  await page.click('#video-form button[type=submit]');
  await plankRow.getByText('File: test.webm').waitFor();

  // non-video file rejected
  const notVideo = path.join(require('os').tmpdir(), 'notvideo.txt'); require('fs').writeFileSync(notVideo, 'hello');
  await plankRow.locator('[data-action=video-edit]').click();
  await page.setInputFiles('#video-form [name=file]', notVideo);
  await page.click('#video-form button[type=submit]');
  await page.waitForFunction(() => /not a video/.test(document.querySelector('#video-error').textContent));
  await page.keyboard.press('Escape');

  // (3) new custom exercise with a video file attached at creation
  await go('admin-exercises');
  await page.waitForSelector('#exercise-form');
  await page.fill('#exercise-form [name=name]', 'Wall sit');
  await page.fill('#exercise-form [name=steps]', 'Back against wall\nSlide down\nHold');
  await page.setInputFiles('#exercise-form [name=file]', VIDEO);
  await page.click('#exercise-form button[type=submit]');
  await page.locator('.saved-list', { hasText: 'Wall sit' }).waitFor();
  await go('admin-videos');
  await page.locator('.table-wrap.tall tr', { hasText: 'Wall sit' }).getByText('File: test.webm').waitFor();

  // admin can preview like a member and also use normal pages
  await plankRow.locator('[data-action=start-ex]').click();
  await page.waitForSelector('#pl-video video');
  await page.waitForFunction(() => { const v = document.querySelector('#pl-video video'); return v && v.readyState >= 1; }, null, { timeout: 8000 });
  assert.equal(await page.locator('#pl-done').count(), 0, 'admin preview has no log button');
  assert.match(await page.textContent('.modal'), /Nothing is logged/);
  await page.keyboard.press('Escape');

  // log out; member signs up on the same page
  await page.click('#logout-btn');
  await page.waitForSelector('#auth-view:not(.hidden)');
  await page.click('[data-auth-tab=signup]');
  await page.fill('#signup-form [name=name]', 'meera k');
  await page.fill('#signup-form [name=email]', ADMIN_EMAIL);
  await page.fill('#signup-form [name=password]', 'secret12');
  await page.click('#signup-form button[type=submit]');
  await page.waitForFunction(() => /already exists/.test(document.querySelector('#signup-error').textContent));
  await page.fill('#signup-form [name=email]', 'meera@example.com');
  await page.click('#signup-form button[type=submit]');
  await page.waitForSelector('#app-view:not(.hidden)');
  await page.waitForFunction(() => location.hash === '#/home');
  assert.ok(!(await page.isVisible('.side-nav [data-route=admin]')));
  assert.ok(await page.isHidden('#admin-nav'));
  // typing the admin URL as a member sends them home
  await page.evaluate(() => { location.hash = '#/admin'; });
  await page.waitForTimeout(200);
  assert.equal(await page.textContent('#page-title'), 'Home');
  assert.equal(await page.textContent('#top-department'), 'Office or desk job');

  // member sees videos on the Exercises page and can watch them
  await go('exercises');
  const squatCard = page.locator('.ex-card', { hasText: 'Bodyweight squats' });
  assert.ok(await squatCard.locator('.tag-video').count() === 1);
  assert.ok(await page.locator('.ex-card', { hasText: 'Jumping jacks' }).locator('.tag-video').count() === 0);
  await squatCard.locator('[data-action=start-ex]').click();
  await page.waitForSelector('#pl-video iframe');
  const src = await page.getAttribute('#pl-video iframe', 'src');
  assert.equal(src, 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ');
  assert.match(await page.textContent('.modal'), /Squat form guide/);
  await page.keyboard.press('Escape');

  const plankCard = page.locator('.ex-card', { hasText: 'Plank holds' });
  await plankCard.locator('[data-action=start-ex]').click();
  await page.waitForSelector('#pl-video video');
  await page.waitForFunction(() => { const v = document.querySelector('#pl-video video'); return v && v.readyState >= 1 && v.videoWidth > 0; }, null, { timeout: 8000 });
  const dims = await page.evaluate(() => { const v = document.querySelector('#pl-video video'); return [v.videoWidth, v.videoHeight, v.src.startsWith('blob:'), v.duration]; });
  assert.deepEqual(dims.slice(0, 3), [320, 180, true]);
  await page.waitForTimeout(300);
  await page.click('#pl-done'); // completing still logs the session
  await page.waitForSelector('.toast-ok');
  // members cannot call admin functions
  const denied = await page.evaluate(async () => { try { await FitLife.backend.adminSetVideoLink('squats', 'https://youtu.be/dQw4w9WgXcQ'); return 'allowed'; } catch (e) { return e.message; } });
  assert.match(denied, /Only the admin/);
  // even editing the stored role in localStorage does not help
  await page.evaluate(() => { const d = JSON.parse(localStorage.getItem('fitlife:v1')); d.users.forEach(u => u.role = 'admin'); localStorage.setItem('fitlife:v1', JSON.stringify(d)); });
  const stillMember = await page.evaluate(() => FitLife.backend.currentUser().role);
  assert.equal(stillMember, 'member');

  // persistence after reload; then admin removes the squat video and member no longer sees it
  await page.reload();
  await page.waitForSelector('#app-view:not(.hidden)');
  await page.click('#logout-btn');
  await login(ADMIN_EMAIL, ADMIN_PW, 'admin');
  await page.waitForFunction(() => location.hash === '#/admin');
  await go('admin-videos');
  page.once('dialog', d => d.accept());
  await page.locator('.table-wrap.tall tr', { hasText: 'Bodyweight squats' }).locator('[data-action=video-remove]').click();
  await page.waitForSelector('.toast-ok:has-text("Video removed")');
  assert.match(await page.locator('.table-wrap.tall tr', { hasText: 'Bodyweight squats' }).innerText(), /No video/);
  // mobile: admin page has no horizontal overflow
  await page.setViewportSize({ width: 390, height: 800 });
  await page.evaluate(() => { location.hash = '#/admin-videos'; });
  await page.waitForTimeout(300);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
  assert.ok(!overflow, 'no horizontal overflow on mobile admin');

  console.log(errors.length ? 'ERRORS:\n' + errors.join('\n') : 'Admin/video UI tests passed, no console errors');
  await browser.close();
  if (errors.length) process.exit(1);
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
