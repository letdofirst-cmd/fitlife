// Member-side UI tests (needs Playwright + a running server: `npm start`, then `npm run test:ui`).
const { chromium } = require('playwright');
const assert = require('assert');
const BASE = process.env.BASE_URL || 'http://localhost:4173/index.html';

(async () => {
  const browser = await chromium.launch();
  const errors = [];
  const watch = (page) => {
    page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.g|ERR_NAME|ERR_INTERNET|Failed to load resource|net::/.test(m.text())) errors.push('console: ' + m.text()); });
  };
  const step = (s) => console.log('  ok  ' + s);

  const ctx = await browser.newContext({ viewport: { width: 1360, height: 900 } });
  const page = await ctx.newPage();
  watch(page);
  await page.clock.install({ time: new Date(2026, 8, 21, 10, 0, 0) }); // Mon 21 Sep 2026, 10:00 local
  await page.goto(BASE);
  const go = async (r) => { await page.click(`.side-nav [data-route=${r}]`); await page.waitForFunction((x) => location.hash === '#/' + x, r); await page.waitForTimeout(60); };
  const toast = (text) => page.locator('.toast', { hasText: text }).first();

  /* ---- sign up ---- */
  await page.click('[data-auth-tab=signup]');
  await page.fill('#signup-form [name=name]', 'shashank soam');
  await page.fill('#signup-form [name=email]', 'bad');
  await page.fill('#signup-form [name=password]', '123456');
  await page.click('#signup-form button[type=submit]');
  assert.match(await page.textContent('#signup-error'), /valid email/);
  await page.fill('#signup-form [name=email]', 'shashank@example.com');
  await page.selectOption('#signup-form [name=occupation]', 'desk');
  await page.click('#signup-form button[type=submit]');
  await page.waitForSelector('#app-view:not(.hidden)');
  assert.equal(await page.textContent('#top-name'), 'Shashank Soam');
  assert.ok(await page.isHidden('#admin-nav'), 'members never see the admin nav');
  step('sign up, name is title-cased, no admin nav');

  /* ---- every page renders without undefined/NaN ---- */
  for (const r of ['home', 'dashboard', 'exercises', 'desk', 'yoga', 'plans', 'nutrition', 'progress', 'leaderboard', 'profile']) {
    await go(r);
    const text = await page.innerText('#page-content');
    assert.ok(text.length > 100, r);
    assert.ok(!/undefined|NaN|\[object|&lt;&gt;/.test(text), r + ' shows a bad value');
  }
  step('all 10 member pages render cleanly');

  /* ---- exercise library ---- */
  await go('exercises');
  assert.ok(await page.locator('#ex-grid .ex-card').count() >= 30);
  await page.click('[data-action=filter-cat][data-value=yoga]');
  assert.equal(await page.locator('#ex-grid .ex-card').count(), 6);
  await page.click('[data-action=filter-level][data-value=intermediate]');
  assert.equal(await page.locator('#ex-grid .ex-card').count(), 1);
  await page.click('[data-action=filter-cat][data-value=all]');
  await page.click('[data-action=filter-level][data-value=all]');
  await page.fill('#ex-search', 'squat');
  assert.equal(await page.locator('#ex-grid .ex-card').count(), 2);
  await page.fill('#ex-search', 'zzzz');
  assert.match(await page.textContent('#ex-grid'), /No exercises match/);
  step('filters and search');

  /* ---- guided routine: plays exercises back to back ---- */
  await go('desk');
  assert.equal(await page.locator('.routine-card').count(), 3, 'three desk routines');
  await page.locator('.routine-card', { hasText: 'Quick desk reset' }).locator('[data-action=start-list]').click();
  await page.waitForSelector('.modal');
  assert.match(await page.textContent('.modal'), /Step 1 of 3/);
  assert.match(await page.textContent('.modal h3'), /Neck rolls/);
  await page.click('#pl-done');
  await page.waitForFunction(() => /Step 2 of 3/.test(document.querySelector('.modal')?.textContent || ''));
  await page.click('#pl-skip'); // skipping logs nothing
  await page.waitForFunction(() => /Step 3 of 3/.test(document.querySelector('.modal')?.textContent || ''));
  await page.click('#pl-done');
  await toast('Routine complete: 2 exercises').waitFor();
  await go('progress');
  assert.equal((await page.locator('.metric').nth(1).innerText()).trim(), '2', 'skipped step was not logged');
  step('routine: step counter, skip, summary, logging');

  /* ---- player: timer, stop early rule, Esc, hitting Complete only once ---- */
  await go('exercises');
  await page.fill('#ex-search', '');
  await page.locator('.ex-card', { hasText: 'Jumping jacks' }).locator('[data-action=start-ex]').click();
  assert.ok(await page.isDisabled('#pl-stop'));
  assert.equal(await page.textContent('#pl-time'), '05:00');
  await page.click('#pl-toggle');
  await page.clock.runFor(31000);
  await page.waitForFunction(() => document.querySelector('#pl-time').textContent !== '05:00');
  assert.ok(await page.isEnabled('#pl-stop'), 'stop early unlocks after 30 seconds');
  await page.click('#pl-stop');
  await toast('min logged').waitFor();
  await go('progress');
  assert.equal(await page.locator('.activity-list.history li').count(), 3);
  step('timer counts down, stop early logs partial time');

  /* ---- undo a logged session ---- */
  const pointsBefore = (await page.locator('.metric').nth(2).innerText()).trim();
  await page.locator('.history li').first().locator('[data-action=session-delete]').click();
  await toast('Session removed').waitFor();
  assert.equal(await page.locator('.history li').count(), 2);
  assert.notEqual((await page.locator('.metric').nth(2).innerText()).trim(), pointsBefore);
  step('session history: undo');

  /* ---- weekly goal ---- */
  await go('profile');
  await page.fill('[name=weeklyGoal]', '5');
  await page.click('#profile-form button[type=submit]');
  assert.match(await page.textContent('#profile-error'), /Weekly goal/);
  await page.fill('[name=weeklyGoal]', '200');
  await page.click('#profile-form button[type=submit]');
  await go('home');
  assert.match(await page.innerText('#page-content'), /of 200 min/);
  await go('dashboard');
  assert.match(await page.innerText('.goal-card'), /of 200 min/);
  step('custom weekly goal shows on Home and Dashboard');

  /* ---- start all from Home ---- */
  await go('home');
  await page.locator('[data-action=start-list]', { hasText: 'Start all' }).click();
  assert.match(await page.textContent('.modal'), /Step 1 of 3/);
  await page.keyboard.press('Escape');
  assert.equal(await page.locator('.modal').count(), 0);
  step('Home: Start all, Esc closes');

  /* ---- plans + play all ---- */
  await go('plans');
  await page.click('[data-action=plan-set][data-id=desk-reset]');
  assert.equal(await page.locator('.day-cell').count(), 7);
  assert.equal(await page.locator('.day-cell.today').count(), 1);
  assert.equal(await page.locator('.day-cell.today b').innerText(), 'Mon');
  await page.locator('.day-cell.today [data-action=start-list]').click();
  assert.match(await page.textContent('.modal'), /Desk Reset: Neck and shoulders/);
  await page.keyboard.press('Escape');
  step('plans: today highlighted, play all');

  /* ---- water + nutrition + minors ---- */
  await go('dashboard');
  await page.click('[data-action=water][data-delta="1"]');
  await page.click('[data-action=water][data-delta="1"]');
  assert.match(await page.textContent('.section-title b'), /2 of 8/);
  await go('nutrition');
  assert.match(await page.innerText('#page-content'), /Add your age, sex, height and weight/);
  const meals1 = await page.locator('.meal-card h4').allInnerTexts();
  await page.click('[data-action=meal-shuffle]');
  assert.notDeepEqual(meals1, await page.locator('.meal-card h4').allInnerTexts());
  await page.selectOption('[data-ui=diet]', 'vegan');
  await page.click('[data-action=meal-save]');
  assert.equal(await page.locator('.saved-list li').count(), 1);
  await go('profile');
  await page.fill('[name=age]', '16'); await page.selectOption('[name=sex]', 'female');
  await page.fill('[name=heightCm]', '165'); await page.fill('[name=weightKg]', '55');
  await page.click('#profile-form button[type=submit]');
  await go('nutrition');
  assert.ok(await page.isDisabled('[data-ui=dir]'), 'under 18: goal locked to maintenance');
  assert.match(await page.innerText('#page-content'), /under 18/);
  await go('profile');
  await page.fill('[name=age]', '28.4');
  await page.click('#profile-form button[type=submit]');
  await go('nutrition');
  assert.ok(await page.isEnabled('[data-ui=dir]'));
  assert.match(await page.innerText('#page-content'), /scaled ×/);
  step('water, nutrition, under-18 safeguard');

  /* ---- backup: download, wipe, restore ---- */
  await go('progress');
  const sessionsBefore = (await page.locator('.metric').nth(1).innerText()).trim();
  await go('profile');
  const [download] = await Promise.all([page.waitForEvent('download'), page.click('[data-action=export]')]);
  const file = await download.path();
  page.once('dialog', (d) => d.accept());
  await page.click('[data-action=reset-progress]');
  await toast('Progress reset').waitFor();
  await go('progress');
  assert.equal((await page.locator('.metric').nth(1).innerText()).trim(), '0');
  await go('profile');
  page.once('dialog', (d) => d.accept());
  await page.setInputFiles('#import-file', file);
  await toast('Restored').waitFor();
  await go('progress');
  assert.equal((await page.locator('.metric').nth(1).innerText()).trim(), sessionsBefore);
  step('backup download, reset, restore');

  /* ---- reminders survive re-renders (regression) and fire on time ---- */
  // From here on the fake clock only moves when the test moves it, so timing is exact.
  await page.clock.pauseAt(new Date((await page.evaluate(() => Date.now())) + 1000));
  await page.click('#reminder-btn');
  await page.check('#reminder-form [name=on]');
  await page.selectOption('#reminder-form [name=every]', '30');
  await page.click('#reminder-form button[type=submit]');
  assert.ok((await page.getAttribute('#reminder-btn', 'class')).includes('active'));
  for (let i = 0; i < 6; i++) {
    await page.clock.runFor(4 * 60 * 1000); // 24 minutes in total, with a re-render every 4 minutes
    await go(i % 2 ? 'nutrition' : 'dashboard');
    if (i % 2 === 0) await page.click('[data-action=water][data-delta="1"]');
  }
  assert.equal(await page.locator('.toast', { hasText: 'movement break' }).count(), 0, 'not due yet');
  await page.clock.runFor(6 * 60 * 1000 + 2000); // just past the 30-minute mark (the toast lasts 7 more seconds)
  await toast('movement break').waitFor();
  step('reminder fires on time even with constant re-rendering');

  /* ---- midnight rollover refreshes "today" ---- */
  await go('home');
  await page.locator('.hero-actions [data-action=start-ex]').click();
  await page.click('#pl-done');
  await go('home');
  assert.match(await page.textContent('.home-hero .lead'), /moved for/);
  await page.clock.setSystemTime(new Date(2026, 8, 22, 0, 5, 0));
  await page.clock.runFor(31000);
  await page.waitForFunction(() => /Nothing logged yet today/.test(document.querySelector('.home-hero .lead')?.textContent || ''));
  step('past midnight the page rolls over to the new day by itself');

  /* ---- persistence + logout/login ---- */
  await page.reload();
  await page.waitForSelector('#app-view:not(.hidden)');
  assert.equal(await page.textContent('#top-name'), 'Shashank Soam');
  await page.click('#logout-btn');
  await page.waitForSelector('#auth-view:not(.hidden)');
  await page.fill('#login-form [name=email]', 'shashank@example.com');
  await page.fill('#login-form [name=password]', 'wrong');
  await page.click('#login-form button[type=submit]');
  await page.waitForFunction(() => document.querySelector('#login-error').textContent.length > 0);
  await page.fill('#login-form [name=password]', '123456');
  await page.click('#login-form button[type=submit]');
  await page.waitForSelector('#app-view:not(.hidden)');
  step('data persists across reload; wrong password refused; login works');

  /* ---- mobile: layout, drawer accessibility ---- */
  const m = await browser.newContext({ viewport: { width: 390, height: 800 } });
  const mp = await m.newPage();
  watch(mp);
  await mp.goto(BASE);
  await mp.click('[data-auth-tab=signup]');
  await mp.fill('#signup-form [name=name]', 'Mia');
  await mp.fill('#signup-form [name=email]', 'mia@example.com');
  await mp.fill('#signup-form [name=password]', 'secret12');
  await mp.click('#signup-form button[type=submit]');
  await mp.waitForSelector('#app-view:not(.hidden)');
  assert.equal(await mp.evaluate(() => getComputedStyle(document.querySelector('#sidebar')).visibility), 'hidden', 'closed drawer is hidden from keyboard users');
  assert.equal(await mp.getAttribute('#mobile-menu', 'aria-expanded'), 'false');
  await mp.click('#mobile-menu');
  await mp.waitForTimeout(300);
  assert.equal(await mp.evaluate(() => getComputedStyle(document.querySelector('#sidebar')).visibility), 'visible');
  assert.equal(await mp.getAttribute('#mobile-menu', 'aria-expanded'), 'true');
  await mp.keyboard.press('Escape');
  await mp.waitForTimeout(300);
  assert.equal(await mp.getAttribute('#mobile-menu', 'aria-expanded'), 'false');
  for (const w of [360, 390, 768, 1024]) {
    await mp.setViewportSize({ width: w, height: 800 });
    for (const r of ['home', 'dashboard', 'exercises', 'desk', 'plans', 'nutrition', 'progress', 'leaderboard', 'profile']) {
      await mp.evaluate((x) => { location.hash = '#/' + x; }, r);
      await mp.waitForTimeout(50);
      const over = await mp.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
      assert.ok(!over, `horizontal overflow on ${r} at ${w}px`);
    }
  }
  step('mobile: drawer a11y, no overflow at 360-1024px');

  console.log(errors.length ? '\nERRORS:\n' + errors.join('\n') : '\nMember UI tests passed, no console errors');
  await browser.close();
  if (errors.length) process.exit(1);
})().catch((e) => { console.error('FAIL', e.message); process.exit(1); });
