#!/usr/bin/env node
/* Change the admin password.
     node tools/make-admin-hash.js "my new password"          -> prints the ADMIN_SEED block
     node tools/make-admin-hash.js "my new password" --write  -> also patches backend.js in place
   Only a salted hash is stored in backend.js, never the password itself. */
'use strict';
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const write = args.includes('--write');
const pw = args.find((a) => !a.startsWith('--'));
if (!pw || pw.length < 8) {
  console.error('Usage: node tools/make-admin-hash.js "<new password, 8+ characters>" [--write]');
  process.exit(1);
}

const salt = 'fl-' + crypto.randomBytes(8).toString('hex');
const text = salt + ':' + pw;
const hash = crypto.createHash('sha256').update(text).digest('hex');
let h = 5381; // the same fallback hash backend.js uses on non-secure origins
for (let i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) >>> 0;
const hashAlt = 'x' + h.toString(16);

const block = `const ADMIN_SEED = {\n    salt: '${salt}',\n    hash: '${hash}',\n    hashAlt: '${hashAlt}', // same password hashed by the fallback used on non-secure origins\n  };`;

if (!write) {
  console.log('Replace the ADMIN_SEED block in backend.js with:\n\n  ' + block + '\n\nOr rerun with --write to do it for you.');
  process.exit(0);
}
const file = path.join(__dirname, '..', 'backend.js');
const src = fs.readFileSync(file, 'utf8');
if (!/const ADMIN_SEED = \{[\s\S]*?\};/.test(src)) { console.error('Could not find ADMIN_SEED in backend.js.'); process.exit(1); }
fs.writeFileSync(file, src.replace(/const ADMIN_SEED = \{[\s\S]*?\};/, block));
console.log('backend.js updated. Reload the app: the admin account picks up the new password automatically.');
